package com.alejandro.eshop;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

import com.alejandro.eshop.controller.EshopController;

public class EshopControllerTest {

    @Test
    void controllerShouldConnectAndReturnUser() {
        try (EshopController controller = new EshopController()) {
            assertEquals("APP", controller.whoAmI());
        }
    }
}
