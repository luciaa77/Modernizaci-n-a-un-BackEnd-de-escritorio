package com.alejandro.eshop.entity;

import jakarta.persistence.*;

@Entity
@Table(
    name = "INFORMACION_FISCAL",
    uniqueConstraints = @UniqueConstraint(name="UK_INFOFISCAL_NIFCIF", columnNames = "NIF_CIF")
)
public class InformacionFiscal {

    @Id
    @Column(name="CLIENTE_ID")
    private Long id;

    @OneToOne(fetch = FetchType.LAZY, optional = false)
    @MapsId
    @JoinColumn(name="CLIENTE_ID", foreignKey = @ForeignKey(name="FK_INFOFISCAL_CLIENTE"))
    private Cliente cliente;

    @Column(name="NIF_CIF", nullable=false, length=20)
    private String nifCif;

    @Column(name="CALLE", nullable=false, length=120)
    private String calle;

    @Column(name="CIUDAD", nullable=false, length=80)
    private String ciudad;

    @Column(name="CODIGO_POSTAL", nullable=false, length=10)
    private String codigoPostal;

    @Column(name="TELEFONO", nullable=false, length=20)
    private String telefono;

    public InformacionFiscal() {}

    public Long getId() { return id; }

    public Cliente getCliente() { return cliente; }
    public void setCliente(Cliente cliente) { this.cliente = cliente; }

    public String getNifCif() { return nifCif; }
    public void setNifCif(String nifCif) { this.nifCif = nifCif; }

    public String getCalle() { return calle; }
    public void setCalle(String calle) { this.calle = calle; }

    public String getCiudad() { return ciudad; }
    public void setCiudad(String ciudad) { this.ciudad = ciudad; }

    public String getCodigoPostal() { return codigoPostal; }
    public void setCodigoPostal(String codigoPostal) { this.codigoPostal = codigoPostal; }

    public String getTelefono() { return telefono; }
    public void setTelefono(String telefono) { this.telefono = telefono; }
}
