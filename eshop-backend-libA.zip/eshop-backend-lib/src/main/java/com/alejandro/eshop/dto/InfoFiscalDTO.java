package com.alejandro.eshop.dto;

public class InfoFiscalDTO {
    public String nifCif;
    public String calle;
    public String ciudad;
    public String codigoPostal;
    public String telefono;

    public InfoFiscalDTO() {}
}
