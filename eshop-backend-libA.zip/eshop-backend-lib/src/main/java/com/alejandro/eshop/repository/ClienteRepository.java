package com.alejandro.eshop.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.alejandro.eshop.entity.Cliente;

public interface ClienteRepository extends JpaRepository<Cliente, Long> {
    boolean existsByEmail(String email);
}
