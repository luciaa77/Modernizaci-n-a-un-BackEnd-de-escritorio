package com.alejandro.eshop.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.alejandro.eshop.entity.Articulo;

public interface ArticuloRepository extends JpaRepository<Articulo, Long> { }
