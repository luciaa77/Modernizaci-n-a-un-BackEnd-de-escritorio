package com.alejandro.eshop.entity;

public enum EstadoCompra {
    PENDIENTE,
    ENVIADO,
    ENTREGADO
}
