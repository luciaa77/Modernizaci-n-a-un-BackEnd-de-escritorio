package com.alejandro.eshop.entity;

import java.math.BigDecimal;

import jakarta.persistence.*;

@Entity
@Table(name = "LINEA_COMPRA")
public class LineaCompra {

    @EmbeddedId
    private LineaCompraId id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @MapsId("compraId")
    @JoinColumn(name = "COMPRA_ID", nullable = false,
            foreignKey = @ForeignKey(name = "FK_LINEA_COMPRA_COMPRA"))
    private Compra compra;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @MapsId("articuloId")
    @JoinColumn(name = "ARTICULO_ID", nullable = false,
            foreignKey = @ForeignKey(name = "FK_LINEA_COMPRA_ARTICULO"))
    private Articulo articulo;

    @Column(name = "CANTIDAD", nullable = false)
    private Integer cantidad;

    // Precio congelado en el momento de compra
    @Column(name = "PRECIO_UNITARIO", nullable = false, precision = 12, scale = 2)
    private BigDecimal precioUnitario;

    public LineaCompra() {}

    public LineaCompra(Compra compra, Articulo articulo, Integer cantidad, BigDecimal precioUnitario) {
        this.compra = compra;
        this.articulo = articulo;
        this.cantidad = cantidad;
        this.precioUnitario = precioUnitario;
        this.id = new LineaCompraId(
                compra != null ? compra.getId() : null,
                articulo != null ? articulo.getId() : null
        );
    }

    @PrePersist
    public void prePersist() {
        if (id == null && compra != null && articulo != null) {
            id = new LineaCompraId(compra.getId(), articulo.getId());
        }
    }

    // Getters/Setters
    public LineaCompraId getId() { return id; }

    public Compra getCompra() { return compra; }
    public void setCompra(Compra compra) {
        this.compra = compra;
        if (id == null) id = new LineaCompraId();
    }

    public Articulo getArticulo() { return articulo; }
    public void setArticulo(Articulo articulo) {
        this.articulo = articulo;
        if (id == null) id = new LineaCompraId();
    }

    public Integer getCantidad() { return cantidad; }
    public void setCantidad(Integer cantidad) { this.cantidad = cantidad; }

    public BigDecimal getPrecioUnitario() { return precioUnitario; }
    public void setPrecioUnitario(BigDecimal precioUnitario) { this.precioUnitario = precioUnitario; }
}
