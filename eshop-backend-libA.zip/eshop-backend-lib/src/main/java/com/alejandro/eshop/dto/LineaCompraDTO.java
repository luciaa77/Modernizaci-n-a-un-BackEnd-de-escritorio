package com.alejandro.eshop.dto;

import java.math.BigDecimal;

public class LineaCompraDTO {
    public Long articuloId;
    public String articuloNombre;
    public Integer cantidad;
    public BigDecimal precioUnitario;

    public LineaCompraDTO() {}
}
