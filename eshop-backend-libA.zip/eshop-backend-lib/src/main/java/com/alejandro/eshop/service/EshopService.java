package com.alejandro.eshop.service;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.alejandro.eshop.dto.ArticuloDTO;
import com.alejandro.eshop.dto.ClienteDTO;
import com.alejandro.eshop.dto.CompraDTO;
import com.alejandro.eshop.dto.InfoFiscalDTO;
import com.alejandro.eshop.dto.LineaCompraDTO;
import com.alejandro.eshop.dto.LineaCompraRequestDTO;
import com.alejandro.eshop.entity.Articulo;
import com.alejandro.eshop.entity.Cliente;
import com.alejandro.eshop.entity.Compra;
import com.alejandro.eshop.entity.EstadoCompra;
import com.alejandro.eshop.entity.InformacionFiscal;
import com.alejandro.eshop.entity.LineaCompra;
import com.alejandro.eshop.repository.ArticuloRepository;
import com.alejandro.eshop.repository.ClienteRepository;
import com.alejandro.eshop.repository.CompraRepository;
import java.util.List;




@Service
public class EshopService {

    private final ClienteRepository clienteRepo;
    private final ArticuloRepository articuloRepo;

    private final CompraRepository compraRepo;

    public EshopService(ClienteRepository clienteRepo, ArticuloRepository articuloRepo, CompraRepository compraRepo) {
        this.clienteRepo = clienteRepo;
        this.articuloRepo = articuloRepo;
        this.compraRepo = compraRepo;
    }


    @Transactional
    public ClienteDTO crearClienteConInfoFiscal(ClienteDTO clienteDto, InfoFiscalDTO infoDto) {
        if (clienteRepo.existsByEmail(clienteDto.email)) {
            throw new IllegalArgumentException("El email ya existe: " + clienteDto.email);
        }

        Cliente c = new Cliente();
        c.setNombreCompleto(clienteDto.nombreCompleto);
        c.setEmail(clienteDto.email);

        InformacionFiscal info = new InformacionFiscal();
        info.setNifCif(infoDto.nifCif);
        info.setCalle(infoDto.calle);
        info.setCiudad(infoDto.ciudad);
        info.setCodigoPostal(infoDto.codigoPostal);
        info.setTelefono(infoDto.telefono);

        c.setInformacionFiscal(info);

        Cliente guardado = clienteRepo.save(c);
        return new ClienteDTO(guardado.getId(), guardado.getNombreCompleto(), guardado.getEmail());
    }

    @Transactional
    public ArticuloDTO crearArticulo(ArticuloDTO dto) {
        Articulo a = new Articulo();
        a.setNombre(dto.nombre);
        a.setDescripcion(dto.descripcion);
        a.setPrecioActual(dto.precioActual);
        a.setStock(dto.stock);

        Articulo g = articuloRepo.save(a);

        ArticuloDTO out = new ArticuloDTO();
        out.id = g.getId();
        out.nombre = g.getNombre();
        out.descripcion = g.getDescripcion();
        out.precioActual = g.getPrecioActual();
        out.stock = g.getStock();
        return out;
    }
    
    @Transactional
    public CompraDTO crearCompra(Long clienteId, String direccionEnvio, List<LineaCompraRequestDTO> lineasReq) {

        if (clienteId == null) throw new IllegalArgumentException("clienteId es obligatorio");
        if (direccionEnvio == null || direccionEnvio.isBlank()) throw new IllegalArgumentException("direccionEnvio es obligatoria");
        if (lineasReq == null || lineasReq.isEmpty()) throw new IllegalArgumentException("La compra debe tener al menos una línea");

        Cliente cliente = clienteRepo.findById(clienteId)
                .orElseThrow(() -> new IllegalArgumentException("No existe cliente con id=" + clienteId));

        Compra compra = new Compra();
        compra.setCliente(cliente);
        compra.setDireccionEnvio(direccionEnvio);
        compra.setEstado(EstadoCompra.PENDIENTE);

        // Por cada línea: validar, congelar precio y descontar stock
        for (LineaCompraRequestDTO req : lineasReq) {
            if (req == null) continue;
            if (req.articuloId == null) throw new IllegalArgumentException("articuloId es obligatorio en una línea");
            if (req.cantidad == null || req.cantidad <= 0) throw new IllegalArgumentException("cantidad debe ser > 0");

            Articulo articulo = articuloRepo.findById(req.articuloId)
                    .orElseThrow(() -> new IllegalArgumentException("No existe artículo con id=" + req.articuloId));

            if (articulo.getStock() == null || articulo.getStock() < req.cantidad) {
                throw new IllegalArgumentException("Stock insuficiente para artículo id=" + articulo.getId()
                        + " (stock=" + articulo.getStock() + ", pedido=" + req.cantidad + ")");
            }

            // congelar precio
            var precioUnitario = articulo.getPrecioActual();

            // descontar stock
            articulo.setStock(articulo.getStock() - req.cantidad);

            // crear línea
            LineaCompra linea = new LineaCompra();
            linea.setArticulo(articulo);
            linea.setCantidad(req.cantidad);
            linea.setPrecioUnitario(precioUnitario);

            compra.addLinea(linea); // mantiene bidireccionalidad
        }

        // Persistimos compra y, por cascade, las líneas.
        Compra guardada = compraRepo.save(compra);

        // Respuesta DTO
        CompraDTO out = new CompraDTO();
        out.id = guardada.getId();
        out.clienteId = guardada.getCliente().getId();
        out.fechaCompra = guardada.getFechaCompra();
        out.estado = guardada.getEstado();
        out.direccionEnvio = guardada.getDireccionEnvio();

        for (LineaCompra l : guardada.getLineas()) {
            LineaCompraDTO ldto = new LineaCompraDTO();
            ldto.articuloId = l.getArticulo().getId();
            ldto.articuloNombre = l.getArticulo().getNombre();
            ldto.cantidad = l.getCantidad();
            ldto.precioUnitario = l.getPrecioUnitario();
            out.lineas.add(ldto);
        }

        return out;
    }

}
