package com.alejandro.eshop.dto;

public class ClienteDTO {
    public Long id;
    public String nombreCompleto;
    public String email;

    public ClienteDTO() {}

    public ClienteDTO(Long id, String nombreCompleto, String email) {
        this.id = id;
        this.nombreCompleto = nombreCompleto;
        this.email = email;
    }
}
