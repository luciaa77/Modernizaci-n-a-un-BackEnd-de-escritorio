package com.alejandro.eshop.dto;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import com.alejandro.eshop.entity.EstadoCompra;

public class CompraDTO {
    public Long id;
    public Long clienteId;
    public LocalDateTime fechaCompra;
    public EstadoCompra estado;
    public String direccionEnvio;
    public List<LineaCompraDTO> lineas = new ArrayList<>();

    public CompraDTO() {}
}
