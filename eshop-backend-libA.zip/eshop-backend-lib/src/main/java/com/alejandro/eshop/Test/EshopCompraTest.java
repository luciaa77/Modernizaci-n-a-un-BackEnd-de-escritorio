package com.alejandro.eshop.Test;


import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.math.BigDecimal;
import java.util.List;

import org.junit.jupiter.api.Test;

import com.alejandro.eshop.controller.EshopController;
import com.alejandro.eshop.dto.ArticuloDTO;
import com.alejandro.eshop.dto.ClienteDTO;
import com.alejandro.eshop.dto.CompraDTO;
import com.alejandro.eshop.dto.InfoFiscalDTO;
import com.alejandro.eshop.dto.LineaCompraRequestDTO;

public class EshopCompraTest {

    @Test
    void shouldCreateCompraFreezePriceAndDiscountStock() {
        try (EshopController c = new EshopController()) {

            // Cliente
            ClienteDTO cli = new ClienteDTO();
            cli.nombreCompleto = "Cliente Compra";
            cli.email = "compra" + System.currentTimeMillis() + "@mail.com";

            InfoFiscalDTO info = new InfoFiscalDTO();
            info.nifCif = "11111111A";
            info.calle = "Calle 1";
            info.ciudad = "Ciudad";
            info.codigoPostal = "13001";
            info.telefono = "600000000";

            ClienteDTO clienteCreado = c.crearClienteConInfoFiscal(cli, info);
            assertNotNull(clienteCreado.id);

            // Articulo
            ArticuloDTO art = new ArticuloDTO();
            art.nombre = "Teclado K1";
            art.descripcion = "Mecánico";
            art.precioActual = new BigDecimal("99.99");
            art.stock = 10;

            ArticuloDTO artCreado = c.crearArticulo(art);
            assertNotNull(artCreado.id);

            // Compra (2 unidades)
            CompraDTO compra = c.crearCompra(
                    clienteCreado.id,
                    "Av. Principal 123, Ciudad 13001",
                    List.of(new LineaCompraRequestDTO(artCreado.id, 2))
            );

            assertNotNull(compra.id);
            assertEquals(1, compra.lineas.size());
            assertEquals(2, compra.lineas.get(0).cantidad);
            assertEquals(new BigDecimal("99.99"), compra.lineas.get(0).precioUnitario);
        }
    }

    @Test
    void shouldFailWhenNotEnoughStock() {
        try (EshopController c = new EshopController()) {

            ClienteDTO cli = new ClienteDTO();
            cli.nombreCompleto = "Cliente Stock";
            cli.email = "stock" + System.currentTimeMillis() + "@mail.com";

            InfoFiscalDTO info = new InfoFiscalDTO();
            info.nifCif = "22222222B";
            info.calle = "Calle 2";
            info.ciudad = "Ciudad";
            info.codigoPostal = "13001";
            info.telefono = "600000001";

            ClienteDTO clienteCreado = c.crearClienteConInfoFiscal(cli, info);

            ArticuloDTO art = new ArticuloDTO();
            art.nombre = "Ratón";
            art.descripcion = "Gaming";
            art.precioActual = new BigDecimal("50.00");
            art.stock = 1;

            ArticuloDTO artCreado = c.crearArticulo(art);

            assertThrows(IllegalArgumentException.class, () ->
                c.crearCompra(clienteCreado.id, "Dir", List.of(new LineaCompraRequestDTO(artCreado.id, 5)))
            );
        }
    }
}
