package com.alejandro.eshop.controller;

import java.util.List;
import java.util.Objects;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.alejandro.eshop.config.PersistenceConfig;
import com.alejandro.eshop.dto.ArticuloDTO;
import com.alejandro.eshop.dto.ClienteDTO;
import com.alejandro.eshop.dto.CompraDTO;
import com.alejandro.eshop.dto.InfoFiscalDTO;
import com.alejandro.eshop.dto.LineaCompraRequestDTO;
import com.alejandro.eshop.service.EshopService;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;

public class EshopController implements AutoCloseable {

    private final AnnotationConfigApplicationContext ctx;
    private final EntityManagerFactory emf;
    private final EshopService service;

    public EshopController() {
        this.ctx = new AnnotationConfigApplicationContext(PersistenceConfig.class);
        this.emf = ctx.getBean(EntityManagerFactory.class);
        this.service = ctx.getBean(EshopService.class);
    }

    /**
     * Prueba rápida: devuelve el usuario actual de Oracle (debería ser APP).
     */
    public String whoAmI() {
        EntityManager em = emf.createEntityManager();
        try {
            Object result = em.createNativeQuery("SELECT USER FROM DUAL").getSingleResult();
            return Objects.toString(result, null);
        } finally {
            em.close();
        }
    }

    /**
     * Crea un cliente con su información fiscal (1:1 obligatorio).
     * Lanza IllegalArgumentException si el email ya existe.
     */
    public ClienteDTO crearClienteConInfoFiscal(ClienteDTO cliente, InfoFiscalDTO infoFiscal) {
        return service.crearClienteConInfoFiscal(cliente, infoFiscal);
    }

    /**
     * Crea un artículo en catálogo.
     */
    public ArticuloDTO crearArticulo(ArticuloDTO articulo) {
        return service.crearArticulo(articulo);
    }

    @Override
    public void close() {
        // Cierra primero EMF, luego el contexto Spring
        if (emf != null) {
            try { emf.close(); } catch (Exception ignored) {}
        }
        if (ctx != null) {
            try { ctx.close(); } catch (Exception ignored) {}
        }
    }
    
    public CompraDTO crearCompra(Long clienteId, String direccionEnvio, List<LineaCompraRequestDTO> lineas) {
        return service.crearCompra(clienteId, direccionEnvio, lineas);
    }

}
