package com.alejandro.eshop.entity;

import java.math.BigDecimal;

import jakarta.persistence.*;

@Entity
@Table(name="ARTICULO")
public class Articulo {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="ID")
    private Long id;

    @Column(name="NOMBRE", nullable=false, length=120)
    private String nombre;

    @Column(name="DESCRIPCION", nullable=false, length=500)
    private String descripcion;

    @Column(name="PRECIO_ACTUAL", nullable=false, precision=12, scale=2)
    private BigDecimal precioActual;

    @Column(name="STOCK", nullable=false)
    private Integer stock;

    public Articulo() {}

    public Long getId() { return id; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }

    public BigDecimal getPrecioActual() { return precioActual; }
    public void setPrecioActual(BigDecimal precioActual) { this.precioActual = precioActual; }

    public Integer getStock() { return stock; }
    public void setStock(Integer stock) { this.stock = stock; }
}
