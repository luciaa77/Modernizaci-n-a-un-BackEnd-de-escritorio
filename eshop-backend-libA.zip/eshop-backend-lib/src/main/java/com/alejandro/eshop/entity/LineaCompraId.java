package com.alejandro.eshop.entity;

import java.io.Serializable;
import java.util.Objects;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;

@Embeddable
public class LineaCompraId implements Serializable {

    @Column(name = "COMPRA_ID")
    private Long compraId;

    @Column(name = "ARTICULO_ID")
    private Long articuloId;

    public LineaCompraId() {}

    public LineaCompraId(Long compraId, Long articuloId) {
        this.compraId = compraId;
        this.articuloId = articuloId;
    }

    public Long getCompraId() { return compraId; }
    public Long getArticuloId() { return articuloId; }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof LineaCompraId that)) return false;
        return Objects.equals(compraId, that.compraId)
            && Objects.equals(articuloId, that.articuloId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(compraId, articuloId);
    }
}
