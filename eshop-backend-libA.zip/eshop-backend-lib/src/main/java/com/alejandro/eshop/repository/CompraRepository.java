package com.alejandro.eshop.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.alejandro.eshop.entity.Compra;

public interface CompraRepository extends JpaRepository<Compra, Long> { }
