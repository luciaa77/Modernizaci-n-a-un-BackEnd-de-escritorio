package com.alejandro.eshop.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.alejandro.eshop.entity.LineaCompra;
import com.alejandro.eshop.entity.LineaCompraId;

public interface LineaCompraRepository extends JpaRepository<LineaCompra, LineaCompraId> { }
