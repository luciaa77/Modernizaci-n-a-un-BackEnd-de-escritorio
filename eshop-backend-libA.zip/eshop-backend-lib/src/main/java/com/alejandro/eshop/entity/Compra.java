package com.alejandro.eshop.entity;

import java.time.LocalDateTime;
import com.alejandro.eshop.entity.LineaCompra;
import java.util.ArrayList;
import java.util.List;
import jakarta.persistence.*;

@Entity
@Table(name = "COMPRA")
public class Compra {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID")
    private Long id;

    @Column(name = "FECHA_COMPRA", nullable = false)
    private LocalDateTime fechaCompra;

    @Enumerated(EnumType.STRING)
    @Column(name = "ESTADO", nullable = false, length = 20)
    private EstadoCompra estado;

    @Column(name = "DIRECCION_ENVIO", nullable = false, length = 250)
    private String direccionEnvio;

    // Cada compra pertenece a un cliente (obligatorio)
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "CLIENTE_ID", nullable = false,
            foreignKey = @ForeignKey(name = "FK_COMPRA_CLIENTE"))
    private Cliente cliente;

    @OneToMany(mappedBy = "compra", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
    private List<LineaCompra> lineas = new ArrayList<>();

    public Compra() {}

    @PrePersist
    public void prePersist() {
        if (fechaCompra == null) fechaCompra = LocalDateTime.now();
        if (estado == null) estado = EstadoCompra.PENDIENTE;
    }

    public void addLinea(LineaCompra linea) {
        lineas.add(linea);
        linea.setCompra(this);
    }

    public void removeLinea(LineaCompra linea) {
        lineas.remove(linea);
        linea.setCompra(null);
    }

    // Getters/Setters
    public Long getId() { return id; }

    public LocalDateTime getFechaCompra() { return fechaCompra; }
    public void setFechaCompra(LocalDateTime fechaCompra) { this.fechaCompra = fechaCompra; }

    public EstadoCompra getEstado() { return estado; }
    public void setEstado(EstadoCompra estado) { this.estado = estado; }

    public String getDireccionEnvio() { return direccionEnvio; }
    public void setDireccionEnvio(String direccionEnvio) { this.direccionEnvio = direccionEnvio; }

    public Cliente getCliente() { return cliente; }
    public void setCliente(Cliente cliente) { this.cliente = cliente; }

    public List<LineaCompra> getLineas() { return lineas; }
}
