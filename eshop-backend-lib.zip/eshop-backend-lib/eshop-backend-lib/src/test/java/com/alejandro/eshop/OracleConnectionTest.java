package com.alejandro.eshop;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.alejandro.eshop.config.PersistenceConfig;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;

/**
 * Test de conectividad a Oracle vía la configuración Spring.
 *
 * @author Alejandro, Andres, Lucia
 * @version 1.0
 */
class OracleConnectionTest {

    @Test
    void shouldConnectToOracle() {
        try (AnnotationConfigApplicationContext ctx = new AnnotationConfigApplicationContext(PersistenceConfig.class)) {
            EntityManagerFactory emf = ctx.getBean(EntityManagerFactory.class);
            assertNotNull(emf);

            EntityManager em = emf.createEntityManager();
            assertNotNull(em);
            em.close();
        }
    }
}
