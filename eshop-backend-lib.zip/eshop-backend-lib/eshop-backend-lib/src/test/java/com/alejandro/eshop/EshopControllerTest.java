package com.alejandro.eshop;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;

import com.alejandro.eshop.controller.EshopController;

/**
 * @version 1.0
 * @author Alejandro,Andres,Lucia
 */
class EshopControllerTest {

    @Test
    void controllerShouldConnectAndReturnUser() {
        try (EshopController controller = new EshopController()) {
            String user = controller.whoAmI();
            assertNotNull(user);
        }
    }
}
