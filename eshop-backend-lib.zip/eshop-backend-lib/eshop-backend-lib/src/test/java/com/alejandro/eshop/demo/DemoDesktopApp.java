package com.alejandro.eshop.demo;
/**
 * @version 1.0
 * @author Alejandro,Andres,Lucia
 */
import java.math.BigDecimal;
import java.util.List;

import com.alejandro.eshop.controller.EshopController;
import com.alejandro.eshop.dto.ArticuloDTO;
import com.alejandro.eshop.dto.ClienteDTO;
import com.alejandro.eshop.dto.CompraDTO;
import com.alejandro.eshop.dto.InfoFiscalDTO;
import com.alejandro.eshop.dto.LineaCompraRequestDTO;

public class DemoDesktopApp {

    public static void main(String[] args) {

        EshopController c = new EshopController();
        try {

            System.out.println("Oracle USER = " + c.whoAmI());

            // 1) Crear cliente + info fiscal (DTO)
            ClienteDTO cli = new ClienteDTO();
            cli.nombreCompleto = "Cliente Demo";
            cli.email = "demo" + System.currentTimeMillis() + "@mail.com";

            InfoFiscalDTO info = new InfoFiscalDTO();
            info.nifCif = "33333333C";
            info.calle = "Calle Demo";
            info.ciudad = "Ciudad";
            info.codigoPostal = "13001";
            info.telefono = "600000002";

            ClienteDTO clienteCreado = c.crearClienteConInfoFiscal(cli, info);
            System.out.println("Cliente creado ID=" + clienteCreado.id);

            // 2) Crear artículo (DTO)
            ArticuloDTO art = new ArticuloDTO();
            art.nombre = "Monitor";
            art.descripcion = "27 pulgadas";
            art.precioActual = new BigDecimal("199.99");
            art.stock = 5;

            ArticuloDTO artCreado = c.crearArticulo(art);
            System.out.println("Articulo creado ID=" + artCreado.id);

            // 3) Crear compra con 2 unidades
            LineaCompraRequestDTO linea = new LineaCompraRequestDTO(artCreado.id, 2);

            CompraDTO compra = c.crearCompra(
                    clienteCreado.id,
                    "Av. Demo 1",
                    List.of(linea)
            );

            System.out.println(
                    "Compra creada ID=" + compra.id +
                    " lineas=" + (compra.lineas != null ? compra.lineas.size() : 0)
            );

        } finally {
            // Si en el futuro el controller necesita liberar recursos,
            // este es el sitio correcto
        }
    }
}
