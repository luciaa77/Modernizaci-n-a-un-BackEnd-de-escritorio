package com.alejandro.eshop.mapper;
/**
 * @version 1.0
 * @author Alejandro,Andres,Lucia
 */
import java.util.ArrayList;
import java.util.List;

import com.alejandro.eshop.dto.CompraDTO;
import com.alejandro.eshop.dto.LineaCompraDTO;
import com.alejandro.eshop.dto.LineaCompraRequestDTO;
import com.alejandro.eshop.entity.Compra;
import com.alejandro.eshop.entity.EstadoCompra;
import com.alejandro.eshop.entity.LineaCompra;
import com.alejandro.eshop.service.EshopService;

public class CompraMapper {

    private CompraMapper() {}

    // RequestDTO -> LineaPedido (clase interna del service)
    public static List<EshopService.LineaPedido> toLineaPedidoList(List<LineaCompraRequestDTO> req) {
        if (req == null) return List.of();

        List<EshopService.LineaPedido> out = new ArrayList<>();
        for (LineaCompraRequestDTO r : req) {
            out.add(new EshopService.LineaPedido(r.articuloId, r.cantidad));
        }
        return out;
    }

    // Entity -> DTO
    public static CompraDTO toDto(Compra c) {
        CompraDTO d = new CompraDTO();
        if (c == null) return d;

        d.id = c.getId();
        d.clienteId = (c.getCliente() != null) ? c.getCliente().getId() : null;

        // estos getters tienen que existir en tu Compra
        d.direccionEnvio = c.getDireccionEnvio();
        d.fechaCompra = c.getFechaCompra();

        EstadoCompra est = c.getEstado();
        d.estado = (est != null) ? est.name() : null;

        d.lineas = new ArrayList<>();
        if (c.getLineas() != null) {
            for (LineaCompra lc : c.getLineas()) {
                LineaCompraDTO ld = new LineaCompraDTO();
                ld.articuloId = (lc.getArticulo() != null) ? lc.getArticulo().getId() : null;
                ld.cantidad = lc.getCantidad();
                ld.precioUnitario = lc.getPrecioUnitario();
                d.lineas.add(ld);
            }
        }

        return d;
    }
}
