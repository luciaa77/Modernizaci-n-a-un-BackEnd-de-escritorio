package com.alejandro.eshop.entity;
/**
 * @version 1.0
 * @author Alejandro,Andres,Lucia
 */
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.*;

@Entity
@Table(
    name = "CLIENTE",
    uniqueConstraints = @UniqueConstraint(name="UK_CLIENTE_EMAIL", columnNames = "EMAIL")
)
public class Cliente {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="ID")
    private Long id;

    @Column(name="NOMBRE_COMPLETO", nullable=false, length=120)
    private String nombreCompleto;

    @Column(name="EMAIL", nullable=false, length=180)
    private String email;

    @Column(name="FECHA_REGISTRO", nullable=false)
    private LocalDateTime fechaRegistro;

    @OneToOne(mappedBy = "cliente", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY, optional = false)
    private InformacionFiscal informacionFiscal;

    @OneToMany(mappedBy = "cliente", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
    private List<Compra> compras = new ArrayList<>();

    public Cliente() {}

    @PrePersist
    public void prePersist() {
        if (fechaRegistro == null) fechaRegistro = LocalDateTime.now();
    }

    // getters/setters EXACTOS
    public Long getId() { return id; }

    public String getNombreCompleto() { return nombreCompleto; }
    public void setNombreCompleto(String nombreCompleto) { this.nombreCompleto = nombreCompleto; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public LocalDateTime getFechaRegistro() { return fechaRegistro; }
    public void setFechaRegistro(LocalDateTime fechaRegistro) { this.fechaRegistro = fechaRegistro; }

    public InformacionFiscal getInformacionFiscal() { return informacionFiscal; }
    public void setInformacionFiscal(InformacionFiscal info) {
        this.informacionFiscal = info;
        if (info != null) info.setCliente(this);
    }

    public List<Compra> getCompras() { return compras; }
}
