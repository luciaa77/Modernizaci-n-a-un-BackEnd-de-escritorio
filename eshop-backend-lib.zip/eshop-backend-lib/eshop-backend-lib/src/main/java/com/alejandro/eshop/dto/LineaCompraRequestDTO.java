package com.alejandro.eshop.dto;
/**
 * @version 1.0
 * @author Alejandro,Andres,Lucia
 */
public class LineaCompraRequestDTO {
    public Long articuloId;
    public Integer cantidad;

    public LineaCompraRequestDTO() {}

    public LineaCompraRequestDTO(Long articuloId, Integer cantidad) {
        this.articuloId = articuloId;
        this.cantidad = cantidad;
    }
}