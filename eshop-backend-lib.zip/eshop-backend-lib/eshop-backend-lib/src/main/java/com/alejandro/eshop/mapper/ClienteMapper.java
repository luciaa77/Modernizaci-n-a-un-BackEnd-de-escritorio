package com.alejandro.eshop.mapper;
/**
 * @version 1.0
 * @author Alejandro,Andres,Lucia
 */
import com.alejandro.eshop.dto.ClienteDTO;
import com.alejandro.eshop.dto.InfoFiscalDTO;
import com.alejandro.eshop.entity.Cliente;
import com.alejandro.eshop.entity.InformacionFiscal;

public class ClienteMapper {

    private ClienteMapper() {}

    // DTO -> Entity (Cliente)
    public static Cliente toEntity(ClienteDTO d) {
        if (d == null) return null;

        Cliente c = new Cliente();
        // id normalmente NO se setea al crear, pero si viene, lo ponemos
        // (Hibernate lo ignora si es nuevo)
        // OJO: tu Cliente no tiene setId, así que no lo tocamos.

        c.setNombreCompleto(d.nombreCompleto);
        c.setEmail(d.email);
        // fechaRegistro NO hace falta setearla: tienes @PrePersist
        return c;
    }

    // DTO -> Entity (InfoFiscal)
    public static InformacionFiscal toEntity(InfoFiscalDTO d) {
        if (d == null) return null;

        InformacionFiscal i = new InformacionFiscal();
        i.setNifCif(d.nifCif);
        i.setCalle(d.calle);
        i.setCiudad(d.ciudad);
        i.setCodigoPostal(d.codigoPostal);
        i.setTelefono(d.telefono);
        return i;
    }

    // Entity -> DTO
    public static ClienteDTO toDto(Cliente c) {
        ClienteDTO d = new ClienteDTO();
        if (c == null) return d;
        d.id = c.getId();
        d.nombreCompleto = c.getNombreCompleto();
        d.email = c.getEmail();
        return d;
    }
}
