package com.alejandro.eshop.repository;
/**
 * @version 1.0
 * @author Alejandro,Andres,Lucia
 */
import org.springframework.data.jpa.repository.JpaRepository;
import com.alejandro.eshop.entity.Articulo;

public interface ArticuloRepository extends JpaRepository<Articulo, Long> { }
