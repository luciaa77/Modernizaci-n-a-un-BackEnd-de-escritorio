package com.alejandro.eshop.entity;
/**
 * @version 1.0
 * @author Alejandro,Andres,Lucia
 */
import java.math.BigDecimal;

import jakarta.persistence.*;

@Entity
@Table(name = "LINEA_COMPRA")
public class LineaCompra {

    @EmbeddedId
    private LineaCompraId id = new LineaCompraId();

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @MapsId("compraId")
    @JoinColumn(name = "COMPRA_ID", nullable = false,
            foreignKey = @ForeignKey(name = "FK_LINEA_COMPRA_COMPRA"))
    private Compra compra;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @MapsId("articuloId")
    @JoinColumn(name = "ARTICULO_ID", nullable = false,
            foreignKey = @ForeignKey(name = "FK_LINEA_COMPRA_ARTICULO"))
    private Articulo articulo;

    @Column(name = "CANTIDAD", nullable = false)
    private Integer cantidad;

    @Column(name = "PRECIO_UNITARIO", nullable = false, precision = 12, scale = 2)
    private BigDecimal precioUnitario;

    public LineaCompra() {}

    public LineaCompra(Compra compra, Articulo articulo, Integer cantidad, BigDecimal precioUnitario) {
        this.compra = compra;
        this.articulo = articulo;
        this.cantidad = cantidad;
        this.precioUnitario = precioUnitario;
        syncId();
    }

    private void syncId() {
        if (id == null) id = new LineaCompraId();
        if (compra != null && compra.getId() != null) id.setCompraId(compra.getId());
        if (articulo != null && articulo.getId() != null) id.setArticuloId(articulo.getId());
    }

    @PrePersist
    public void prePersist() {
        syncId();
    }

    public LineaCompraId getId() { return id; }
    public void setId(LineaCompraId id) { this.id = id; }

    public Compra getCompra() { return compra; }
    public void setCompra(Compra compra) { this.compra = compra; syncId(); }

    public Articulo getArticulo() { return articulo; }
    public void setArticulo(Articulo articulo) { this.articulo = articulo; syncId(); }

    public Integer getCantidad() { return cantidad; }
    public void setCantidad(Integer cantidad) { this.cantidad = cantidad; }

    public BigDecimal getPrecioUnitario() { return precioUnitario; }
    public void setPrecioUnitario(BigDecimal precioUnitario) { this.precioUnitario = precioUnitario; }
}
