package com.alejandro.eshop.mapper;
/**
 * @version 1.0
 * @author Alejandro,Andres,Lucia
 */
import com.alejandro.eshop.dto.ArticuloDTO;
import com.alejandro.eshop.entity.Articulo;

/**
 * Mapper Articulo <-> ArticuloDTO.
 */
public final class ArticuloMapper {

    private ArticuloMapper() {}

    public static Articulo toEntity(ArticuloDTO dto) {
        Articulo a = new Articulo();
        a.setNombre(dto.nombre);
        a.setDescripcion(dto.descripcion);
        a.setPrecioActual(dto.precioActual);
        a.setStock(dto.stock);
        return a;
    }

    public static ArticuloDTO toDto(Articulo a) {
        ArticuloDTO out = new ArticuloDTO();
        out.id = a.getId();
        out.nombre = a.getNombre();
        out.descripcion = a.getDescripcion();
        out.precioActual = a.getPrecioActual();
        out.stock = a.getStock();
        return out;
    }
}
