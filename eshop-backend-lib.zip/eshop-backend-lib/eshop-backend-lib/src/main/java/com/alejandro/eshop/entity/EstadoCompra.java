package com.alejandro.eshop.entity;
/**
 * @version 1.0
 * @author Alejandro,Andres,Lucia
 */
public enum EstadoCompra {
    PENDIENTE,
    ENVIADO,
    ENTREGADO
}
