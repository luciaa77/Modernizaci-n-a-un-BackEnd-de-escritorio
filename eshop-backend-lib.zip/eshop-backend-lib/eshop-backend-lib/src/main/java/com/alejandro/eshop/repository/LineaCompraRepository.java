package com.alejandro.eshop.repository;
/**
 * @version 1.0
 * @author Alejandro,Andres,Lucia
 */
import java.util.List;
import java.util.Optional;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.alejandro.eshop.entity.LineaCompra;
import com.alejandro.eshop.entity.LineaCompraId;

/**
 * DAO interno de LineaCompra (clave compuesta).
 *
 * @author Alejandro
 */
@Repository
@Transactional
class LineaCompraDao {

    @PersistenceContext
    private EntityManager em;

    /**
     * Guarda una línea de compra.
     *
     * @param linea línea a persistir
     *
     * @author Alejandro
     */
    public void save(LineaCompra linea) {
        if (linea == null) {
            throw new IllegalArgumentException("La línea de compra no puede ser null");
        }
        em.persist(linea);
    }

    /**
     * Busca una línea por su ID compuesto.
     *
     * @param id clave compuesta
     * @return Optional con la línea si existe
     *
     * @author Alejandro
     */
    public Optional<LineaCompra> findById(LineaCompraId id) {
        if (id == null) {
            return Optional.empty();
        }
        return Optional.ofNullable(em.find(LineaCompra.class, id));
    }

    /**
     * Elimina una línea de compra.
     *
     * @param id clave compuesta
     *
     * @author Alejandro
     */
    public void deleteById(LineaCompraId id) {
        if (id == null) {
            return;
        }
        LineaCompra lc = em.find(LineaCompra.class, id);
        if (lc != null) {
            em.remove(lc);
        }
    }

    /**
     * Devuelve todas las líneas de una compra.
     *
     * @param idCompra id de la compra
     * @return lista de líneas
     *
     * @author Alejandro
     */
    public List<LineaCompra> findByCompraId(Long idCompra) {
        return em.createQuery(
                "SELECT l FROM LineaCompra l WHERE l.compra.id = :idCompra",
                LineaCompra.class)
                .setParameter("idCompra", idCompra)
                .getResultList();
    }
}
