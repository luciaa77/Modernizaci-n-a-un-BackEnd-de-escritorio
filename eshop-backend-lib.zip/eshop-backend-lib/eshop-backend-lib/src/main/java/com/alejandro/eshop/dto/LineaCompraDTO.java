package com.alejandro.eshop.dto;
/**
 * @version 1.0
 * @author Alejandro,Andres,Lucia
 */
import java.math.BigDecimal;

public class LineaCompraDTO {
    public Long articuloId;
    public String articuloNombre;
    public Integer cantidad;
    public BigDecimal precioUnitario;

    public LineaCompraDTO() {}
}
