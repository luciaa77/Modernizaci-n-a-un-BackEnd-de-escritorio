package com.alejandro.eshop.config;

import java.util.Properties;
import javax.sql.DataSource;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.dao.annotation.PersistenceExceptionTranslationPostProcessor;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.annotation.EnableTransactionManagement;

/**
 * @version 1.0
 * @author Alejandro,Andres,Lucia
 */
@Configuration
@EnableTransactionManagement
@ComponentScan(basePackages = "com.alejandro.eshop")
@PropertySource("classpath:eshop.properties")
public class PersistenceConfig {

    @Bean
    public DataSource dataSource(Environment env) {
        DriverManagerDataSource ds = new DriverManagerDataSource();
        ds.setDriverClassName(env.getProperty("eshop.datasource.driverClassName", "oracle.jdbc.OracleDriver"));
        ds.setUrl(env.getProperty("eshop.datasource.url"));
        ds.setUsername(env.getProperty("eshop.datasource.username"));
        ds.setPassword(env.getProperty("eshop.datasource.password"));
        return ds;
    }

    @Bean
    public LocalContainerEntityManagerFactoryBean entityManagerFactory(DataSource dataSource, Environment env) {
        LocalContainerEntityManagerFactoryBean emf = new LocalContainerEntityManagerFactoryBean();
        emf.setDataSource(dataSource);

        // ESCANEA entidades + repos + servicios
        emf.setPackagesToScan("com.alejandro.eshop");

        emf.setJpaVendorAdapter(new HibernateJpaVendorAdapter());

        Properties props = new Properties();
        String schema = env.getProperty("eshop.hibernate.default_schema");
        if (schema != null && !schema.isBlank()) props.put("hibernate.default_schema", schema);

        props.put("hibernate.hbm2ddl.auto", env.getProperty("eshop.hibernate.hbm2ddl.auto", "validate"));
        props.put("hibernate.show_sql", env.getProperty("eshop.hibernate.show_sql", "false"));
        props.put("hibernate.format_sql", env.getProperty("eshop.hibernate.format_sql", "false"));

        emf.setJpaProperties(props);
        return emf;
    }

    @Bean
    public JpaTransactionManager transactionManager(LocalContainerEntityManagerFactoryBean emf) {
        JpaTransactionManager tx = new JpaTransactionManager();
        tx.setEntityManagerFactory(emf.getObject());
        return tx;
    }

    @Bean
    public PersistenceExceptionTranslationPostProcessor exceptionTranslation() {
        return new PersistenceExceptionTranslationPostProcessor();
    }
}
