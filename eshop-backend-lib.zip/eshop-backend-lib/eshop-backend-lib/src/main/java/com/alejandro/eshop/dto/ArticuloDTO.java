package com.alejandro.eshop.dto;

import java.math.BigDecimal;
/**
 * @version 1.0
 * @author Alejandro,Andres,Lucia
 */
public class ArticuloDTO {
    public Long id;
    public String nombre;
    public String descripcion;
    public BigDecimal precioActual;
    public Integer stock;

    public ArticuloDTO() {}
}
