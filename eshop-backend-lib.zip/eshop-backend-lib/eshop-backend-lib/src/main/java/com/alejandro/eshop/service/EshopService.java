package com.alejandro.eshop.service;
/**
 * @version 1.0
 * @author Alejandro,Andres,Lucia
 */
import java.time.LocalDateTime;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.alejandro.eshop.entity.Articulo;
import com.alejandro.eshop.entity.Cliente;
import com.alejandro.eshop.entity.Compra;
import com.alejandro.eshop.entity.EstadoCompra;
import com.alejandro.eshop.entity.InformacionFiscal;
import com.alejandro.eshop.entity.LineaCompra;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;

/**
 * Servicio de negocio principal de eShop.
 *
 * Nota: Implementación sin Spring Data (sin JpaRepository). Acceso a datos mediante EntityManager.
 */
@Service
public class EshopService {

    @PersistenceContext
    private EntityManager em;

    /**
     * Devuelve el usuario actual de Oracle.
     *
     * @return usuario Oracle
     */
    @Transactional(readOnly = true)
    public String whoAmI() {
        return (String) em.createNativeQuery("SELECT USER FROM DUAL").getSingleResult();
    }

    /**
     * Crea un cliente con su información fiscal asociada (1-1).
     *
     * @param cliente cliente
     * @param infoFiscal info fiscal (opcional)
     * @return cliente persistido     */
    @Transactional
    public Cliente crearClienteConInfoFiscal(Cliente cliente, InformacionFiscal infoFiscal) {
        if (cliente == null) throw new IllegalArgumentException("Cliente null");
        if (cliente.getEmail() == null || cliente.getEmail().isBlank())
            throw new IllegalArgumentException("Email obligatorio");
        if (cliente.getNombreCompleto() == null || cliente.getNombreCompleto().isBlank())
            throw new IllegalArgumentException("NombreCompleto obligatorio");

        // (Opcional pero muy recomendable) evitar duplicados por email
        if (existsClienteByEmail(cliente.getEmail())) {
            throw new IllegalArgumentException("Ya existe un cliente con ese email");
        }

        if (cliente.getFechaRegistro() == null) {
            cliente.setFechaRegistro(LocalDateTime.now());
        }

        // vínculo 1-1 (según tu modelo, tu setter puede poner el back-reference)
        if (infoFiscal != null) {
            cliente.setInformacionFiscal(infoFiscal);
        }

        em.persist(cliente);
        return cliente;
    }

    /**
     * Crea un artículo.
     *
     * @param a artículo
     * @return artículo persistido
     */
    @Transactional
    public Articulo crearArticulo(Articulo a) {
        if (a == null) throw new IllegalArgumentException("Articulo null");
        if (a.getNombre() == null || a.getNombre().isBlank())
            throw new IllegalArgumentException("Nombre obligatorio");
        if (a.getDescripcion() == null || a.getDescripcion().isBlank())
            throw new IllegalArgumentException("Descripcion obligatoria");
        if (a.getPrecioActual() == null)
            throw new IllegalArgumentException("PrecioActual obligatorio");
        if (a.getStock() == null) a.setStock(0);

        em.persist(a);
        return a;
    }

    /**
     * Crea una compra para un cliente con sus líneas.
     *
     * @param clienteId id del cliente
     * @param direccionEnvio dirección
     * @param lineas líneas del pedido (articuloId + cantidad)
     * @return compra persistida     */
    @Transactional
    public Compra crearCompra(Long clienteId, String direccionEnvio, List<LineaPedido> lineas) {
        if (clienteId == null) throw new IllegalArgumentException("clienteId null");
        if (direccionEnvio == null || direccionEnvio.isBlank())
            throw new IllegalArgumentException("Dirección obligatoria");
        if (lineas == null || lineas.isEmpty())
            throw new IllegalArgumentException("Debes enviar líneas");

        Cliente cliente = em.find(Cliente.class, clienteId);
        if (cliente == null) {
            throw new IllegalArgumentException("Cliente no existe");
        }

        Compra compra = new Compra();
        compra.setCliente(cliente);
        compra.setDireccionEnvio(direccionEnvio);
        compra.setFechaCompra(LocalDateTime.now());
        compra.setEstado(EstadoCompra.PENDIENTE);

        // Persistimos la compra primero para que quede MANAGED en el contexto de persistencia
        em.persist(compra);

        for (LineaPedido lp : lineas) {
            if (lp == null) {
                throw new IllegalArgumentException("Línea null");
            }
            if (lp.articuloId == null) {
                throw new IllegalArgumentException("articuloId null");
            }
            if (lp.cantidad <= 0) {
                throw new IllegalArgumentException("La cantidad debe ser > 0");
            }

            Articulo art = em.find(Articulo.class, lp.articuloId);
            if (art == null) {
                throw new IllegalArgumentException("Artículo no existe: " + lp.articuloId);
            }

            Integer stock = art.getStock();
            if (stock == null) stock = 0;

            if (stock < lp.cantidad) {
                throw new IllegalArgumentException("No hay stock suficiente para el artículo: " + lp.articuloId);
            }

            LineaCompra lc = new LineaCompra();
            lc.setCompra(compra);
            lc.setArticulo(art);
            lc.setCantidad(lp.cantidad);
            lc.setPrecioUnitario(art.getPrecioActual());

            // Añadir a la compra (si tu lista está inicializada en la entidad, perfecto)
            if (compra.getLineas() != null) {
                compra.getLineas().add(lc);
            }

            // Persistimos la línea explícitamente (funciona incluso sin cascade)
            em.persist(lc);

            // Descontar stock (managed -> se sincroniza en commit)
            art.setStock(stock - lp.cantidad);
        }

        // Devuelve entidad gestionada
        return compra;
    }

    /**
     * Comprueba existencia de cliente por email.
     *
     * @param email email
     * @return true si existe
     */
    @Transactional(readOnly = true)
    protected boolean existsClienteByEmail(String email) {
        Long count = em.createQuery(
                "SELECT COUNT(c) FROM Cliente c WHERE c.email = :email",
                Long.class)
                .setParameter("email", email)
                .getSingleResult();

        return count != null && count > 0;
    }

    /**
     * Helper interno (no DTO aquí).
     *
     */
    public static class LineaPedido {
        public final Long articuloId;
        public final int cantidad;

        public LineaPedido(Long articuloId, int cantidad) {
            this.articuloId = articuloId;
            this.cantidad = cantidad;
        }
    }
}
