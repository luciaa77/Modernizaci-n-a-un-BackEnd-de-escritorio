package com.alejandro.eshop.dto;
/**
 * @version 1.0
 * @author Alejandro,Andres,Lucia
 */
public class InfoFiscalDTO {
    public String nifCif;
    public String calle;
    public String ciudad;
    public String codigoPostal;
    public String telefono;

    public InfoFiscalDTO() {}
}
