package com.alejandro.eshop.dto;
/**
 * @version 1.0
 * @author Alejandro,Andres,Lucia
 */
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class CompraDTO {
    public Long id;
    public Long clienteId;
    public LocalDateTime fechaCompra;
    public String estado; // changed from EstadoCompra to String to represent the name
    public String direccionEnvio;
    public List<LineaCompraDTO> lineas = new ArrayList<>();

    public CompraDTO() {}
}