package com.alejandro.eshop.controller;

import java.util.List;
import java.util.Objects;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.alejandro.eshop.config.PersistenceConfig;
import com.alejandro.eshop.dto.ArticuloDTO;
import com.alejandro.eshop.dto.ClienteDTO;
import com.alejandro.eshop.dto.CompraDTO;
import com.alejandro.eshop.dto.InfoFiscalDTO;
import com.alejandro.eshop.dto.LineaCompraRequestDTO;
import com.alejandro.eshop.entity.Articulo;
import com.alejandro.eshop.entity.Cliente;
import com.alejandro.eshop.entity.Compra;
import com.alejandro.eshop.entity.InformacionFiscal;
import com.alejandro.eshop.mapper.ArticuloMapper;
import com.alejandro.eshop.mapper.ClienteMapper;
import com.alejandro.eshop.mapper.CompraMapper;
import com.alejandro.eshop.service.EshopService;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
/**
 * @version 1.0
 * @author Alejandro,Andres,Lucia
 */
/**
 * Fachada pública de la librería eShop.
 * Public API uses DTOs; controller maps to entities and calls service.
 */
public class EshopController implements AutoCloseable {

    private final AnnotationConfigApplicationContext ctx;
    private final EntityManagerFactory emf;
    private final EshopService service;

    public EshopController() {
        this.ctx = new AnnotationConfigApplicationContext(PersistenceConfig.class);
        this.emf = ctx.getBean(EntityManagerFactory.class);
        this.service = ctx.getBean(EshopService.class);
    }

    public String whoAmI() {
        EntityManager em = emf.createEntityManager();
        try {
            Object result = em.createNativeQuery("SELECT USER FROM DUAL").getSingleResult();
            return Objects.toString(result, null);
        } finally {
            em.close();
        }
    }

    // DTO-based facade
    public ClienteDTO crearClienteConInfoFiscal(ClienteDTO cliente, InfoFiscalDTO infoFiscal) {
        Cliente c = ClienteMapper.toEntity(cliente);
        InformacionFiscal info = ClienteMapper.toEntity(infoFiscal);

        Cliente guardado = service.crearClienteConInfoFiscal(c, info);
        return ClienteMapper.toDto(guardado);
    }

    public ArticuloDTO crearArticulo(ArticuloDTO articulo) {
        Articulo a = ArticuloMapper.toEntity(articulo);
        Articulo guardado = service.crearArticulo(a);
        return ArticuloMapper.toDto(guardado);
    }

    public CompraDTO crearCompra(Long clienteId, String direccionEnvio, List<LineaCompraRequestDTO> lineas) {
        var pedidos = CompraMapper.toLineaPedidoList(lineas);
        Compra compra = service.crearCompra(clienteId, direccionEnvio, pedidos);
        return CompraMapper.toDto(compra);
    }

    @Override
    public void close() {
        try { if (emf != null) emf.close(); } catch (Exception ignored) {}
        try { if (ctx != null) ctx.close(); } catch (Exception ignored) {}
    }
}