package com.alejandro.eshop.entity;
/**
 * @version 1.0
 * @author Alejandro,Andres,Lucia
 */
import java.io.Serializable;
import java.util.Objects;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;

@Embeddable
public class LineaCompraId implements Serializable {

    @Column(name = "COMPRA_ID")
    private Long compraId;

    @Column(name = "ARTICULO_ID")
    private Long articuloId;

    public LineaCompraId() {}

    public LineaCompraId(Long compraId, Long articuloId) {
        this.compraId = compraId;
        this.articuloId = articuloId;
    }

    public Long getCompraId() { return compraId; }
    public void setCompraId(Long compraId) { this.compraId = compraId; }

    public Long getArticuloId() { return articuloId; }
    public void setArticuloId(Long articuloId) { this.articuloId = articuloId; }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof LineaCompraId that)) return false;
        return Objects.equals(compraId, that.compraId)
            && Objects.equals(articuloId, that.articuloId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(compraId, articuloId);
    }
}
