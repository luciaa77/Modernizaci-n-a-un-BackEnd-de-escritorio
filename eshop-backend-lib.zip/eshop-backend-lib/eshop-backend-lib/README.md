# eshop-backend-lib

Librería backend (JAR) para la práctica. Usa Spring + Hibernate/JPA y se conecta a Oracle.

## Requisitos
- Java 17
- Oracle (Servicio: FREEPDB1)
- Usuario de aplicación: APP

## Configuración BD (actual)
- URL: jdbc:oracle:thin:@//localhost:1521/FREEPDB1
- USER: APP

## Ejecutar tests
mvn test

## Generar JAR
mvn clean package

El JAR se genera en:
target/eshop-backend-lib-1.0.0.jar
