# PARTE 3 — FRONT DESKTOP + INTEGRACIÓN DEL JAR (LUCÍA)

Este proyecto es el **Front Desktop** (Maven) preparado para consumir el backend cuando exista como **librería (JAR)**.
Mientras no exista el JAR real, el Front usa un **Mock** en memoria para poder avanzar y demostrar la UI y las pruebas.

## Requisitos
- Java 17
- Maven
- Eclipse/IntelliJ (opcional)

## Cómo ejecutar
### Opción 1: con Maven
En la raíz del proyecto:
```bash
mvn clean package
mvn -q exec:java
```

### Opción 2: desde IDE
Ejecuta:
- `src/main/java/com/alejandro/eshop/desktop/Main.java`

## Menú / Funcionalidades
1) Crear cliente  
2) Listar artículos  
3) Crear compra  
9) Pruebas visibles (caso normal + errores)  
0) Salir  

## Pruebas visibles (opción 9)
- Caso normal:
  - Crea un cliente válido
  - Lista artículos
  - Crea una compra con stock
- Caso error 1: email duplicado
- Caso error 2: sin stock

## Integración del JAR (cuando exista)
### Opción A (recomendada): dependencia Maven
1. En el proyecto backend (librería): `mvn clean install`
2. En este `pom.xml`, añade la dependencia del backend:
```xml
<dependency>
  <groupId>com.alejandro</groupId>
  <artifactId>eshop-backend</artifactId>
  <version>1.0.0</version>
</dependency>
```

### Opción B: instalar un JAR suelto en Maven local
```bash
mvn install:install-file \
  -Dfile=/RUTA/AL/JAR/eshop-backend-1.0.0.jar \
  -DgroupId=com.alejandro \
  -DartifactId=eshop-backend \
  -Dversion=1.0.0 \
  -Dpackaging=jar
```

### Adapter real
Implementa `com.alejandro.eshop.desktop.adapter.jar.JarEshopBackendAdapter` usando:
- `import com.alejandro.eshop.controller.*;`
- `import com.alejandro.eshop.dto.*;`

y cambia en `Main`:
- de `MockEshopBackendAdapter` a `JarEshopBackendAdapter`.

