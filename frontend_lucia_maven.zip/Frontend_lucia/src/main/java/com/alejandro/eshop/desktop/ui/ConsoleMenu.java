package com.alejandro.eshop.desktop.ui;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.alejandro.eshop.desktop.adapter.EshopBackendPort;
import com.alejandro.eshop.desktop.adapter.exceptions.DuplicateEmailException;
import com.alejandro.eshop.desktop.adapter.exceptions.NotFoundException;
import com.alejandro.eshop.desktop.adapter.exceptions.OutOfStockException;
import com.alejandro.eshop.desktop.adapter.exceptions.ValidationException;
import com.alejandro.eshop.desktop.adapter.model.ArticuloVM;
import com.alejandro.eshop.desktop.adapter.model.CompraLineaVM;
import com.alejandro.eshop.desktop.adapter.model.CompraVM;
import com.alejandro.eshop.desktop.adapter.model.ClienteVM;

/**
 * Menú de consola del Front Desktop.
 *
 * @author Lucía
 */
public class ConsoleMenu {

    private final EshopBackendPort backend;
    private final Scanner sc = new Scanner(System.in);

    /**
     * Constructor.
     *
     * @param backend backend port (mock o jar)
     * @author Lucía
     */
    public ConsoleMenu(EshopBackendPort backend) {
        this.backend = backend;
    }

    /**
     * Ejecuta el menú principal.
     *
     * @author Lucía
     */
    public void run() {
        int opcion;
        do {
            printMenu();
            opcion = readInt("Elige opción: ");

            try {
                switch (opcion) {
                    case 1 -> crearCliente();
                    case 2 -> listarArticulos();
                    case 3 -> crearCompra();
                    case 9 -> ejecutarPruebasVisibles();
                    case 0 -> System.out.println("Saliendo...");
                    default -> System.out.println("[INFO] Opción no válida.");
                }
            } catch (DuplicateEmailException | OutOfStockException | NotFoundException | ValidationException ex) {
                System.out.println("[ERROR] " + ex.getMessage());
            } catch (Exception ex) {
                System.out.println("[ERROR] Error inesperado: " + ex.getMessage());
            }

            System.out.println();
        } while (opcion != 0);
    }

    /**
     * Imprime el menú.
     *
     * @author Lucía
     */
    private void printMenu() {
        System.out.println("==================================");
        System.out.println("        ESHOP DESKTOP (Front)      ");
        System.out.println("==================================");
        System.out.println("1) Crear cliente");
        System.out.println("2) Listar artículos");
        System.out.println("3) Crear compra");
        System.out.println("9) Ejecutar pruebas visibles");
        System.out.println("0) Salir");
    }

    /**
     * Caso de uso: crear cliente.
     *
     * @author Lucía
     */
    private void crearCliente() {
        System.out.println("---- Crear cliente ----");
        String nombre = readString("Nombre: ");
        String email = readString("Email: ");

        ClienteVM c = backend.crearCliente(nombre, email);
        System.out.println("[OK] Cliente creado -> id=" + c.id() + ", nombre=" + c.nombre() + ", email=" + c.email());
    }

    /**
     * Caso de uso: listar artículos.
     *
     * @author Lucía
     */
    private void listarArticulos() {
        System.out.println("---- Listar artículos ----");
        List<ArticuloVM> arts = backend.listarArticulos();
        if (arts.isEmpty()) {
            System.out.println("[INFO] No hay artículos.");
            return;
        }

        System.out.printf("%-5s %-20s %-10s %-6s%n", "ID", "NOMBRE", "PRECIO", "STOCK");
        for (ArticuloVM a : arts) {
            System.out.printf("%-5d %-20s %-10.2f %-6d%n", a.id(), a.nombre(), a.precio(), a.stock());
        }
    }

    /**
     * Caso de uso: crear compra.
     *
     * @author Lucía
     */
    private void crearCompra() {
        System.out.println("---- Crear compra ----");
        long clienteId = readLong("Cliente ID: ");

        listarArticulos();

        List<CompraLineaVM> lineas = new ArrayList<>();
        while (true) {
            long artId = readLong("Artículo ID (0 para terminar): ");
            if (artId == 0) break;

            int unidades = readInt("Unidades: ");
            lineas.add(new CompraLineaVM(artId, unidades));
        }

        CompraVM compra = backend.crearCompra(clienteId, lineas);
        System.out.println("[OK] Compra creada -> id=" + compra.id() + ", total=" + String.format("%.2f", compra.total()));
        System.out.println("     Líneas: " + compra.lineas().size() + " | Fecha: " + compra.fecha());
    }

    /**
     * Ejecuta pruebas visibles (caso normal + casos de error).
     *
     * @author Lucía
     */
    private void ejecutarPruebasVisibles() {
        System.out.println("---- Pruebas visibles ----");

        // Caso normal
        System.out.println(">> Caso normal: crear cliente + listar artículos + comprar con stock");
        ClienteVM c1 = backend.crearCliente("Cliente Normal", "normal@correo.com");
        System.out.println("[OK] Cliente creado -> " + c1);

        listarArticulos();
        CompraVM compraOk = backend.crearCompra(c1.id(), List.of(new CompraLineaVM(1, 1)));
        System.out.println("[OK] Compra OK -> " + compraOk);

        // Caso error: email duplicado
        System.out.println("\n>> Caso error: email duplicado");
        try {
            backend.crearCliente("Otro", "normal@correo.com");
            System.out.println("[ERROR] Esto no debería imprimirse (esperábamos excepción).");
        } catch (DuplicateEmailException ex) {
            System.out.println("[OK] Error controlado -> " + ex.getMessage());
        }

        // Caso error: sin stock
        System.out.println("\n>> Caso error: sin stock");
        try {
            backend.crearCompra(c1.id(), List.of(new CompraLineaVM(3, 999)));
            System.out.println("[ERROR] Esto no debería imprimirse (esperábamos excepción).");
        } catch (OutOfStockException ex) {
            System.out.println("[OK] Error controlado -> " + ex.getMessage());
        }

        System.out.println("---- Fin pruebas ----");
    }

    /**
     * Lee String no vacío.
     *
     * @param label etiqueta
     * @return texto
     * @author Lucía
     */
    private String readString(String label) {
        while (true) {
            System.out.print(label);
            String s = sc.nextLine();
            if (s != null && !s.trim().isEmpty()) return s.trim();
            System.out.println("[INFO] No puede estar vacío.");
        }
    }

    /**
     * Lee int con control.
     *
     * @param label etiqueta
     * @return int
     * @author Lucía
     */
    private int readInt(String label) {
        while (true) {
            System.out.print(label);
            String s = sc.nextLine();
            try {
                return Integer.parseInt(s.trim());
            } catch (NumberFormatException ex) {
                System.out.println("[INFO] Introduce un número válido.");
            }
        }
    }

    /**
     * Lee long con control.
     *
     * @param label etiqueta
     * @return long
     * @author Lucía
     */
    private long readLong(String label) {
        while (true) {
            System.out.print(label);
            String s = sc.nextLine();
            try {
                return Long.parseLong(s.trim());
            } catch (NumberFormatException ex) {
                System.out.println("[INFO] Introduce un número válido.");
            }
        }
    }
}
