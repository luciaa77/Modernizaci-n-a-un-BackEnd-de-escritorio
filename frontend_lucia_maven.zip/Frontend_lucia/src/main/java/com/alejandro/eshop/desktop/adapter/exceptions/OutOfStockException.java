package com.alejandro.eshop.desktop.adapter.exceptions;

/**
 * Error: stock insuficiente.
 *
 * @author Lucía
 */
public class OutOfStockException extends RuntimeException {

    /**
     * Constructor.
     *
     * @param message mensaje de error
     * @author Lucía
     */
    public OutOfStockException(String message) {
        super(message);
    }
}
