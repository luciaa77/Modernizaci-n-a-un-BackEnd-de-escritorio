package com.alejandro.eshop.desktop.adapter.model;

import java.time.LocalDateTime;
import java.util.List;

/**
 * ViewModel de Compra para mostrar el resultado en el Front.
 *
 * @author Lucía
 */
public record CompraVM(long id, long clienteId, LocalDateTime fecha, List<CompraLineaVM> lineas, double total) { }
