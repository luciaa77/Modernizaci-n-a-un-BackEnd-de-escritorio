package com.alejandro.eshop.desktop.adapter.mock;

import java.time.LocalDateTime;
import java.util.*;
import java.util.concurrent.atomic.AtomicLong;

import com.alejandro.eshop.desktop.adapter.EshopBackendPort;
import com.alejandro.eshop.desktop.adapter.exceptions.DuplicateEmailException;
import com.alejandro.eshop.desktop.adapter.exceptions.NotFoundException;
import com.alejandro.eshop.desktop.adapter.exceptions.OutOfStockException;
import com.alejandro.eshop.desktop.adapter.exceptions.ValidationException;
import com.alejandro.eshop.desktop.adapter.model.ArticuloVM;
import com.alejandro.eshop.desktop.adapter.model.ClienteVM;
import com.alejandro.eshop.desktop.adapter.model.CompraLineaVM;
import com.alejandro.eshop.desktop.adapter.model.CompraVM;

/**
 * Adapter Mock: simula el backend en memoria.
 * Sirve para desarrollar el Front sin depender del JAR.
 *
 * @author Lucía
 */
public class MockEshopBackendAdapter implements EshopBackendPort {

    private final AtomicLong clienteSeq = new AtomicLong(1);
    private final AtomicLong compraSeq = new AtomicLong(1);

    private final Map<Long, ClienteVM> clientesById = new HashMap<>();
    private final Map<String, Long> emailToClienteId = new HashMap<>();

    private final Map<Long, ArticuloVM> articulosById = new HashMap<>();

    /**
     * Constructor: carga datos iniciales para poder probar.
     *
     * @author Lucía
     */
    public MockEshopBackendAdapter() {
        // Datos iniciales de artículos (id, nombre, precio, stock)
        articulosById.put(1L, new ArticuloVM(1L, "Teclado mecánico", 59.99, 10));
        articulosById.put(2L, new ArticuloVM(2L, "Ratón gaming", 29.90, 5));
        articulosById.put(3L, new ArticuloVM(3L, "Monitor 24\"", 149.00, 2));
    }

    @Override
    public ClienteVM crearCliente(String nombre, String email) {
        validarTexto(nombre, "nombre");
        validarTexto(email, "email");
        validarEmail(email);

        String key = email.toLowerCase(Locale.ROOT).trim();
        if (emailToClienteId.containsKey(key)) {
            throw new DuplicateEmailException("Ya existe un cliente con ese email: " + email);
        }

        long id = clienteSeq.getAndIncrement();
        ClienteVM cliente = new ClienteVM(id, nombre.trim(), email.trim());
        clientesById.put(id, cliente);
        emailToClienteId.put(key, id);
        return cliente;
    }

    @Override
    public List<ArticuloVM> listarArticulos() {
        // Devuelve una copia ordenada por id
        List<ArticuloVM> list = new ArrayList<>(articulosById.values());
        list.sort(Comparator.comparingLong(ArticuloVM::id));
        return list;
    }

    @Override
    public CompraVM crearCompra(long clienteId, List<CompraLineaVM> lineas) {
        if (!clientesById.containsKey(clienteId)) {
            throw new NotFoundException("No existe el cliente con id=" + clienteId);
        }
        if (lineas == null || lineas.isEmpty()) {
            throw new ValidationException("La compra debe tener al menos una línea.");
        }

        // Primero validamos stock SIN modificar
        for (CompraLineaVM linea : lineas) {
            if (linea.unidades() <= 0) {
                throw new ValidationException("Unidades inválidas para artículo " + linea.articuloId());
            }

            ArticuloVM art = articulosById.get(linea.articuloId());
            if (art == null) {
                throw new NotFoundException("No existe el artículo con id=" + linea.articuloId());
            }
            if (linea.unidades() > art.stock()) {
                throw new OutOfStockException("Sin stock para '" + art.nombre() + "'. Stock=" + art.stock()
                        + ", solicitado=" + linea.unidades());
            }
        }

        // Si todo OK, descontamos stock y calculamos total
        double total = 0.0;
        for (CompraLineaVM linea : lineas) {
            ArticuloVM art = articulosById.get(linea.articuloId());
            int nuevoStock = art.stock() - linea.unidades();
            ArticuloVM actualizado = new ArticuloVM(art.id(), art.nombre(), art.precio(), nuevoStock);
            articulosById.put(art.id(), actualizado);

            total += art.precio() * linea.unidades();
        }

        long compraId = compraSeq.getAndIncrement();
        return new CompraVM(compraId, clienteId, LocalDateTime.now(), List.copyOf(lineas), total);
    }

    /**
     * Valida texto no vacío.
     *
     * @param value valor
     * @param field nombre del campo
     * @author Lucía
     */
    private void validarTexto(String value, String field) {
        if (value == null || value.trim().isEmpty()) {
            throw new ValidationException("El campo '" + field + "' no puede estar vacío.");
        }
    }

    /**
     * Validación simple de email.
     *
     * @param email email
     * @author Lucía
     */
    private void validarEmail(String email) {
        String e = email.trim();
        if (!e.contains("@") || e.startsWith("@") || e.endsWith("@")) {
            throw new ValidationException("Email inválido: " + email);
        }
    }
}
