package com.alejandro.eshop.desktop.adapter.jar;

import java.util.List;

import com.alejandro.eshop.desktop.adapter.EshopBackendPort;
import com.alejandro.eshop.desktop.adapter.model.ArticuloVM;
import com.alejandro.eshop.desktop.adapter.model.ClienteVM;
import com.alejandro.eshop.desktop.adapter.model.CompraLineaVM;
import com.alejandro.eshop.desktop.adapter.model.CompraVM;

/**
 * Adapter REAL contra el backend del JAR.
 *
 * Cuando exista el JAR del backend (librería), aquí podrás importar:
 *   import com.alejandro.eshop.controller.*;
 *   import com.alejandro.eshop.dto.*;
 *
 * y mapear DTO -> VM.
 *
 * @author Lucía
 */
public class JarEshopBackendAdapter implements EshopBackendPort {

    /**
     * Constructor.
     *
     * @author Lucía
     */
    public JarEshopBackendAdapter() {
        // Inicializar controllers (o ApplicationContext) cuando exista el JAR real.
    }

    @Override
    public ClienteVM crearCliente(String nombre, String email) {
        throw new UnsupportedOperationException("Implementar con el JAR real");
    }

    @Override
    public List<ArticuloVM> listarArticulos() {
        throw new UnsupportedOperationException("Implementar con el JAR real");
    }

    @Override
    public CompraVM crearCompra(long clienteId, List<CompraLineaVM> lineas) {
        throw new UnsupportedOperationException("Implementar con el JAR real");
    }
}
