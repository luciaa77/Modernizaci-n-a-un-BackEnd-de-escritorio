package com.alejandro.eshop.desktop;

import com.alejandro.eshop.desktop.adapter.EshopBackendPort;
import com.alejandro.eshop.desktop.adapter.mock.MockEshopBackendAdapter;
import com.alejandro.eshop.desktop.ui.ConsoleMenu;

/**
 * Punto de entrada del Front Desktop.
 *
 * @author Lucía
 */
public class Main {

    /**
     * Arranque.
     *
     * @param args args
     * @author Lucía
     */
    public static void main(String[] args) {
        // Por ahora usamos MOCK para poder avanzar sin el JAR
        EshopBackendPort backend = new MockEshopBackendAdapter();

        // Cuando exista el JAR, cambiarás esta línea por el adapter real del JAR
        // EshopBackendPort backend = new JarEshopBackendAdapter(...);

        new ConsoleMenu(backend).run();
    }
}
