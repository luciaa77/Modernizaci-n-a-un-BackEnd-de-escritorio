package com.alejandro.eshop.desktop.adapter.exceptions;

/**
 * Error: validación de datos de entrada.
 *
 * @author Lucía
 */
public class ValidationException extends RuntimeException {

    /**
     * Constructor.
     *
     * @param message mensaje de error
     * @author Lucía
     */
    public ValidationException(String message) {
        super(message);
    }
}
