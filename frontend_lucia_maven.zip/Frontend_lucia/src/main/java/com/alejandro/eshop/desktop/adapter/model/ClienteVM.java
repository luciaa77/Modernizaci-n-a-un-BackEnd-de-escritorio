package com.alejandro.eshop.desktop.adapter.model;

/**
 * ViewModel de Cliente para el Front.
 *
 * @author Lucía
 */
public record ClienteVM(long id, String nombre, String email) { }
