package com.alejandro.eshop.desktop.adapter;

import java.util.List;

import com.alejandro.eshop.desktop.adapter.model.ArticuloVM;
import com.alejandro.eshop.desktop.adapter.model.ClienteVM;
import com.alejandro.eshop.desktop.adapter.model.CompraLineaVM;
import com.alejandro.eshop.desktop.adapter.model.CompraVM;

/**
 * Contrato que el Front usa para hablar con el backend.
 * Ahora lo implementa un Mock; cuando exista el JAR, lo implementará un adapter real.
 *
 * @author Lucía
 */
public interface EshopBackendPort {

    /**
     * Crea un cliente.
     *
     * @param nombre nombre del cliente
     * @param email email (único)
     * @return cliente creado
     * @author Lucía
     */
    ClienteVM crearCliente(String nombre, String email);

    /**
     * Lista artículos disponibles.
     *
     * @return lista de artículos
     * @author Lucía
     */
    List<ArticuloVM> listarArticulos();

    /**
     * Crea una compra descontando stock y calculando total.
     *
     * @param clienteId id de cliente
     * @param lineas líneas de compra
     * @return compra creada
     * @author Lucía
     */
    CompraVM crearCompra(long clienteId, List<CompraLineaVM> lineas);
}
