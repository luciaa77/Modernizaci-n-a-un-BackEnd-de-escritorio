package com.alejandro.eshop.desktop.adapter.exceptions;

/**
 * Error: email duplicado.
 *
 * @author Lucía
 */
public class DuplicateEmailException extends RuntimeException {

    /**
     * Constructor.
     *
     * @param message mensaje de error
     * @author Lucía
     */
    public DuplicateEmailException(String message) {
        super(message);
    }
}
