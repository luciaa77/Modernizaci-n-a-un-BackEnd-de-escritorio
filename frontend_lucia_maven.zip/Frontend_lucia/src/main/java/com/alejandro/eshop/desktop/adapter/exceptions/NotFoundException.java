package com.alejandro.eshop.desktop.adapter.exceptions;

/**
 * Error: recurso no encontrado (cliente/artículo).
 *
 * @author Lucía
 */
public class NotFoundException extends RuntimeException {

    /**
     * Constructor.
     *
     * @param message mensaje de error
     * @author Lucía
     */
    public NotFoundException(String message) {
        super(message);
    }
}
