package com.alejandro.eshop.desktop.adapter.model;

/**
 * Línea de compra (artículo + unidades).
 *
 * @author Lucía
 */
public record CompraLineaVM(long articuloId, int unidades) { }
