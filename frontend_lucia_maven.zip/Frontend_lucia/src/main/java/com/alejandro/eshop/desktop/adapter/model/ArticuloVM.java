package com.alejandro.eshop.desktop.adapter.model;

/**
 * ViewModel de Artículo para el Front.
 *
 * @author Lucía
 */
public record ArticuloVM(long id, String nombre, double precio, int stock) { }
